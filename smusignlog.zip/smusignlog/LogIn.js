import React, { useState } from 'react'
import { StyleSheet, Image, View, Text } from 'react-native'
import Button from './Button'
import { TextInput } from 'react-native-paper'
const LogIn = () => {
    const [email, Setemail] = useState('');
    const [password, Setpassword] = useState('');
    return (
        <View style={styles.container}>
            <Image style={styles.logoStyle}
                source={require('./logoM.png')}>

            </Image>
            <Text style={styles.headerText}>
                Welcome To SMU
            </Text>
            <TextInput
                style={styles.input}
                selectionColor='green'
                value={email}
                onChange={Setemail}
                autoCapitalize='none'
                autoCompleteType='email'
                placeholder='Enter Your Email'
                keyboardType='email-address'>
            </TextInput>
            <TextInput
                style={styles.input}
                selectionColor='green'
                value={password}
                onChange={Setpassword}
                autoCompleteType='password'
                placeholder='Enter Your password'
                keyboardType='password'
                secureTextEntry={true}
            >
            </TextInput>
            <Text style={styles.forgotPassword}>
                Forgot Your Password ?
            </Text>
            <Button style={styles.button}>
                Log In
            </Button>
            <Text>Already Have An Account ?</Text><Text style={{color:'blue'}}>Sign Up</Text>




        </View>





    );
};
export default LogIn;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        width: '100%',
        maxWidth: 340,
        alignSelf: 'center',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logoStyle: {
        width: 250,
        height: 110,
        marginBottom: 8,
    },
    headerText: {
        fontSize: 21,
        color: "#0283a9",
        fontWeight: 'bold',
        paddingVertical: 12,
    },
    forgotPassword: {
        width: '100%',
        alignItems:'center',
        marginBottom: 24,
        color: 'blue'
    },
    row: {
        flexDirection: 'row',
        marginTop: 4,
    },
    forgot: {
        fontSize: 13,
        color: "#0283a9",
    },
    link: {
        fontWeight: 'bold',
        color: "#0283a9",
    },
    input: {
        width: '100%',
        marginVertical: 12,
        backgroundColor: 'white',
    },
    button: {
        width: '35%',
        height: 60,
        marginVertical: 10,
        paddingVertical: 2,
        backgroundColor: "#0283a9",
        fontWeight: 'bold',
        fontSize: 15,
        lineHeight: 26,
    },
})