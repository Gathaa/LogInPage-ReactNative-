import React from 'react';
import { Text, StyleSheet, View } from 'react-native';
const HomeScreen = () => {
    return (
        <Text>Hi Junior!</Text>
    );
};
const styles = StyleSheet.create({});
export default HomeScreen;