import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { StyleSheet } from 'react-native';
import LogIn from './LogIn';
import HomeScreen from './HomeScreen'
const navigator = createStackNavigator(
  {
    Log: LogIn,
    Home : HomeScreen,

  },
  {
    initialRouteName: 'Log',
    defaultNavigationOptions: {
      title: 'Application',
    },
  },
  {
    initialRouteName: 'Home',
    defaultNavigationOptions: {
      title: 'Application',
    },
  }
);
export default createAppContainer(navigator);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
